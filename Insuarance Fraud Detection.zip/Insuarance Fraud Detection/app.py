from flask import Flask, request, jsonify, send_from_directory
import joblib
import pandas as pd
import numpy as np
import os

app = Flask(__name__, static_folder='static')

# Load the trained machine learning model
MODEL_PATH = "fraud_model.joblib"
try:
    model_pipeline = joblib.load(MODEL_PATH)
    print("Model loaded successfully!")
except Exception as e:
    print(f"Error loading model: {e}")
    model_pipeline = None

# Route to serve the main HTML frontend
@app.route("/")
def home():
    return send_from_directory("static", "index.html")

# Route for handling predictions
@app.route("/predict", methods=["POST"])
def predict_fraud():
    if model_pipeline is None:
        return jsonify({"status": "error", "detail": "Model not loaded."}), 500
        
    try:
        # Get data from the frontend
        claim_data = request.json
        
        # Convert JSON into a Pandas DataFrame
        # Notice we are handling the hyphenated column names needed by the model
        claim_data['capital-gains'] = claim_data.pop('capital_gains', 0)
        claim_data['capital-loss'] = claim_data.pop('capital_loss', 0)
        
        input_df = pd.DataFrame([claim_data])
        
        # Make the prediction
        prediction = model_pipeline.predict(input_df)
        probability = model_pipeline.predict_proba(input_df)[0][1] # Probability of Class 1 (Fraud)
        
        # Interpret the result
        result = "Fraud" if prediction[0] == 1 else "Genuine"
        
        # Send the response back to the frontend
        return jsonify({
            "prediction": result,
            "probability_of_fraud": float(probability),
            "status": "success"
        })
    except Exception as e:
        return jsonify({"status": "error", "detail": str(e)}), 400

if __name__ == "__main__":
    print("Starting Flask application...")
    # Run the Flask app on localhost (127.0.0.0) at port 5000
    app.run(host="0.0.0.0", port=5000, debug=True)
