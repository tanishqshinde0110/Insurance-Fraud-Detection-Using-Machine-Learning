# Insurance Fraud Detection Project

## Overview
Insurance is made to provide a relief amount for any damage caused as a means of protection from financial loss. Unfortunately, many people claim insurance fraudulently. It is called a scam or a fraud claim when a claimant attempts to obtain some benefit or advantage they are not entitled to. These types of insurance claims cause huge financial losses to the company.

The number of detected cases of insurance fraud is much lower than the acts actually committed. Therefore, the main purpose of this **Insurance Fraud Detection** system is to predict whether an insurance claim is a **Fraud** or a **Legal/Genuine Claim** based on different appeals and parameters.

---

## Scenarios Addressed

### Scenario 1: Automobile Insurance Fraud Detection
Machine learning is used to analyze vehicle damage details, claim amounts, and customer history. The system identifies suspicious auto insurance claims and classifies them as fraud or genuine. This helps insurance companies reduce financial losses and speed up claim processing.

### Scenario 2: Health Insurance Fraud Detection
The model detects fraudulent health claims by analyzing treatment codes, billing patterns, and claim frequency. It identifies overbilling, duplicate claims, and unnecessary medical procedures. This ensures fair payouts and prevents misuse of healthcare insurance funds.

### Scenario 3: Property Insurance Fraud Detection
Machine learning evaluates property value, claim timing, and damage reports to detect fraud. The system flags inflated or false claims related to fire, theft, or natural disasters. This supports risk managers in making accurate and data-driven claim decisions.

---

## Project Phases

### 1. Data Collection & Understanding
*   **Data Source**: We used `.csv` data downloaded from Kaggle: [Auto Insurance Claims Data](https://www.kaggle.com/datasets/buntyshah/auto-insurance-claims-data)
*   The data contains claim details, customer information, and corresponding fraud labels.

### 2. Data Preprocessing & Feature Engineering
*   Handled missing values, duplicates, and categorical variables.
*   Applied techniques like `StandardScaler` for numerical columns and `OneHotEncoder` for categorical strings.

### 3. Exploratory Data Analysis (EDA)
There are multiple visualization and analysis techniques possible. In this project, we analyze claim distributions, correlations, and target variable imbalances to understand patterns between fraudulent and genuine claims.

### 4. Model Building & Evaluation
*   **Algorithm**: We opted for **Random Forest Classification**. (Other applicable algorithms include Logistic Regression, Decision Trees, KNN, and XGBoost).
*   Evaluated the model using the Classification Report (precision, recall, f1-score) and the Confusion Matrix focusing on fraud detection accuracy.

### 5. Fraud Prediction & Reporting
*   A **Flask Web Application** provides the interface.
*   The best-performing model is used to predict real-time inputs. Results highlight high-risk claims for further investigation.

---

## Impact
*   **Social Impact**: Improved patient care. By providing accurate and up-to-date information on claims/drugs, it can help professionals make informed decisions, leading to better care.
*   **Business Impact**: Prevents financial losses for the insurance company, allowing funds to be focused on fast, fair payouts for genuine claimants.

---

## How to Run

1. **Install Requirements:**
   ```bash
   pip install flask scikit-learn pandas numpy joblib
   ```

2. **Train the Model:**
   ```bash
   python train.py
   ```
   *(This script preprocesses the `claims_data.csv` and saves a `fraud_model.joblib` file).*

3. **Start the Web Application:**
   ```bash
   python app.py
   ```
   *(Running this command will start a standard Flask web server on `http://localhost:5000/`)*
