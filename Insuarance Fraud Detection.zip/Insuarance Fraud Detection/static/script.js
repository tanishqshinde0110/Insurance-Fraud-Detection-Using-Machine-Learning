document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('claimForm');
    const submitBtn = document.getElementById('submitBtn');
    const btnText = form.querySelector('.btn-text');
    const btnLoader = document.getElementById('btnLoader');
    const resultPanel = document.getElementById('resultPanel');
    const scoreCircle = document.getElementById('scoreCircle');
    const scoreValue = document.getElementById('scoreValue');
    const predictionResult = document.getElementById('predictionResult');
    const predictionMessage = document.getElementById('predictionMessage');

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        // UI Loading State
        btnText.style.display = 'none';
        btnLoader.style.display = 'block';
        submitBtn.disabled = true;
        resultPanel.style.display = 'none';

        // Gather Data
        const formData = new FormData(form);
        const data = {};
        
        // Properly parse inputs based on expected types
        const inputs = form.querySelectorAll('input, select');
        inputs.forEach(input => {
            if(input.id) {
                let val = input.value;
                if(input.type === 'number') {
                    val = val.includes('.') ? parseFloat(val) : parseInt(val);
                }
                data[input.id] = val;
            }
        });

        try {
            const response = await fetch('/predict', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data),
            });

            if (!response.ok) throw new Error('Prediction request failed.');

            const result = await response.json();
            
            // Artificial delay for effect
            setTimeout(() => {
                displayResult(result);
                btnLoader.style.display = 'none';
                btnText.style.display = 'block';
                submitBtn.disabled = false;
            }, 800);

        } catch (error) {
            console.error('Error:', error);
            alert('An error occurred during risk assessment. Ensure API is running.');
            btnLoader.style.display = 'none';
            btnText.style.display = 'block';
            submitBtn.disabled = false;
        }
    });

    function displayResult(result) {
        resultPanel.style.display = 'block';
        
        // Remove previous classes
        resultPanel.classList.remove('fraud', 'genuine');
        
        const isFraud = result.prediction.toLowerCase() === 'fraud';
        const prob = (result.probability_of_fraud * 100).toFixed(1);
        
        if (isFraud) {
            resultPanel.classList.add('fraud');
            predictionResult.textContent = 'High Fraud Risk';
            predictionMessage.textContent = 'This claim exhibits multiple patterns associated with fraudulent activity. Requires manual investigation.';
            document.querySelector('.shape-1').style.background = 'rgba(239, 68, 68, 0.4)';
        } else {
            resultPanel.classList.add('genuine');
            predictionResult.textContent = 'Genuine Claim';
            predictionMessage.textContent = 'This claim aligns with normal patterns. Approved for standard processing timeline.';
            document.querySelector('.shape-1').style.background = 'rgba(16, 185, 129, 0.4)';
        }

        // Animate Circle
        // The stroke-dasharray is circumference, empty_space
        // Here our circumference is ~100
        requestAnimationFrame(() => {
            scoreCircle.setAttribute('stroke-dasharray', `${prob}, 100`);
            scoreValue.textContent = `${prob}%`;
        });
        
        // Scroll to result
        resultPanel.scrollIntoView({ behavior: 'smooth', block: 'end' });
    }
});

// Helper to fill suspicious data
function fillSuspiciousClaim() {
    document.getElementById('months_as_customer').value = 2; // young policy
    document.getElementById('age').value = 22; // young driver
    document.getElementById('total_claim_amount').value = 95000; // massive claim
    document.getElementById('incident_type').value = 'Single Vehicle Collision';
    document.getElementById('incident_severity').value = 'Total Loss';
    document.getElementById('police_report_available').value = 'NO'; // no police report
    document.getElementById('number_of_vehicles_involved').value = 3; // mismatch with single collision
    document.getElementById('insured_hobbies').value = 'cross-fit'; // specific high fraud correlation pattern from our generator
    
    // flash affect
    document.body.style.opacity = '0.5';
    setTimeout(() => { document.body.style.opacity = '1'; }, 100);
}
